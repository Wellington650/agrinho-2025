// ==========================================================
// VARIÁVEIS GLOBAIS
// ==========================================================
let carro;
let elementosCenario = []; // Array para todos os obstáculos e itens (unificado)
let vidaCarro = 100;
let combustivelCarro = 100;
let pontuacao = 0;

let velocidadeCenarioBase = 4; // Velocidade inicial do movimento do cenário
let velocidadeCenarioAtual = velocidadeCenarioBase; // Velocidade que aumenta com a dificuldade
let velocidadeMaxima = 20; // Limite de velocidade (Aumentado para 20 km/h conforme solicitado)

let distanciaParaTransicao = 2000; // Distância para trocar de cenário (em "pontos" de cenário)
let distanciaPercorridaNoCenario = 0; // Contagem para a transição
let modoCenario = 'campo'; // Pode ser 'campo' ou 'cidade'

// Cores do cenário (para facilitar a mudança)
const cores = {
  ceu: [135, 206, 235], // Azul claro
  estradaCampo: [139, 69, 19], // Marrom para estrada de terra
  campoVerde: [34, 139, 34],      // Verde para o campo
  estradaCidade: [80, 80, 80],    // Cinza escuro para asfalto
  calcadaCidade: [150, 150, 150], // Cinza claro para calçadas
  ceuNoite: [25, 25, 112],       // Azul escuro para noite (para futuras expansões)
};

// ==========================================================
// FUNÇÕES DE INICIALIZAÇÃO (SETUP)
// ==========================================================
function setup() {
  createCanvas(400, 700); // Tela um pouco maior para melhor visualização
  carro = new Carro();
  // Inicializa alguns elementos para começar
  gerarElementosIniciais(modoCenario);
}

// ==========================================================
// LOOP PRINCIPAL DO JOGO (DRAW)
// ==========================================================
function draw() {
  // Desenha o fundo com base no modo de cenário
  desenharFundo();

  // Desenha e move o carro
  carro.mostrar();
  carro.mover();

  // Gerencia todos os elementos do cenário (obstáculos e itens)
  gerenciarElementosCenario();

  // Atualiza e exibe a interface do usuário
  atualizarIU();

  // Verifica as condições de Game Over
  verificarGameOver();

  // Atualiza a pontuação e a distância percorrida para transição
  pontuacao += velocidadeCenarioAtual * 0.05; // Pontuação aumenta com o avanço e velocidade
  distanciaPercorridaNoCenario += velocidadeCenarioAtual;

  // Aumenta a velocidade progressivamente
  if (velocidadeCenarioAtual < velocidadeMaxima) {
    velocidadeCenarioAtual += 0.0005; // Ajuste este valor para mudar a dificuldade
  }

  // Verifica a transição de cenário
  if (distanciaPercorridaNoCenario >= distanciaParaTransicao) {
    alternarCenario();
    distanciaPercorridaNoCenario = 0; // Reseta para a próxima transição
  }
}

// ==========================================================
// CLASSES DO JOGO
// ==========================================================

// --- CLASSE CARRO ---
class Carro {
  constructor() {
    this.largura = 40;
    this.altura = 70;
    this.x = width / 2 - this.largura / 2; // Centraliza X
    this.y = height - 120; // Perto da parte inferior da tela
    this.velocidadeLateral = 5; // Velocidade de movimento para os lados
  }

  mostrar() {
    fill(255, 0, 0); // Carro vermelho
    rect(this.x, this.y, this.largura, this.altura);

    // Detalhes do carro (opcional)
    fill(0); // Rodas
    rect(this.x, this.y + 10, 5, 15);
    rect(this.x + this.largura - 5, this.y + 10, 5, 15);
    rect(this.x, this.y + this.altura - 25, 5, 15);
    rect(this.x + this.largura - 5, this.y + this.altura - 25, 5, 15);

    fill(173, 216, 230); // Para-brisa
    rect(this.x + 5, this.y + 5, this.largura - 10, 15);
  }

  mover() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.velocidadeLateral;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.velocidadeLateral;
    }
    // Limita o carro à área jogável (estrada)
    this.x = constrain(this.x, width / 4, width * 3 / 4 - this.largura);

    // Consumo de combustível
    combustivelCarro -= 0.01; // Consome combustível constantemente (ajuste o valor)
    if (combustivelCarro <= 0) {
      combustivelCarro = 0;
      // Lógica de Game Over será tratada em verificarGameOver()
    }
  }
}

// --- CLASSE ELEMENTO (Base para Obstáculos e Itens) ---
class Elemento {
  constructor(x, y, largura, altura, tipo, cenario, cor = null) {
    this.x = x;
    this.y = y;
    this.largura = largura;
    this.altura = altura;
    this.tipo = tipo;      // Ex: 'arvore', 'predio', 'combustivel', 'trator', 'carro_npc'
    this.cenario = cenario; // 'campo' ou 'cidade'
    this.cor = cor;        // Cor específica se definida
  }

  mostrar() {
    // Implementação padrão, será sobrescrita pelas classes específicas
    fill(this.cor || 150); // Cor padrão se nenhuma for definida
    rect(this.x, this.y, this.largura, this.altura);
  }

  mover() {
    this.y += velocidadeCenarioAtual;
  }
}

// --- CLASSE OBSTACULO (Herda de Elemento) ---
class Obstaculo extends Elemento {
  constructor(x, y, largura, altura, tipo, cenario, dano) {
    super(x, y, largura, altura, tipo, cenario);
    this.dano = dano;
  }

  mostrar() {
    // Desenha o obstáculo de acordo com o tipo e cenário
    switch (this.tipo) {
      case 'arvore':
        fill(100, 50, 0); // Tronco
        rect(this.x + this.largura / 2 - 5, this.y, 10, this.altura);
        fill(0, 100, 0); // Folhas
        ellipse(this.x + this.largura / 2, this.y + this.altura / 4, this.largura, this.altura * 0.75);
        break;
      case 'pedra':
        fill(120); // Pedra cinza
        ellipse(this.x + this.largura / 2, this.y + this.altura / 2, this.largura, this.altura);
        break;
      case 'trator':
        fill(139, 0, 0); // Corpo do trator vermelho escuro
        rect(this.x, this.y + this.altura * 0.3, this.largura, this.altura * 0.7);
        fill(255, 255, 0); // Cabine amarela
        rect(this.x + this.largura * 0.2, this.y, this.largura * 0.6, this.altura * 0.4);
        fill(50); // Pneus
        ellipse(this.x + 5, this.y + this.altura - 10, 15, 15);
        ellipse(this.x + this.largura - 5, this.y + this.altura - 10, 20, 20);
        break;
      case 'predio':
        fill(100, 100, 100); // Prédio cinza
        rect(this.x, this.y, this.largura, this.altura);
        fill(255, 255, 0, 180); // Janelas (amarelas e semi-transparentes)
        for (let j = 0; j < this.altura / 20; j++) {
          for (let k = 0; k < this.largura / 20; k++) {
            rect(this.x + 5 + k * 20, this.y + 5 + j * 20, 10, 10);
          }
        }
        break;
      case 'poste':
        fill(50, 50, 50); // Poste
        rect(this.x + this.largura / 2 - 2, this.y, 4, this.altura);
        fill(255, 255, 0); // Lâmpada
        ellipse(this.x + this.largura / 2, this.y, 10, 10);
        break;
      case 'carro_npc':
        fill(random(50, 200), random(50, 200), random(50, 200)); // Cor aleatória para o carro NPC
        rect(this.x, this.y, this.largura, this.altura);
        fill(0); // Rodas
        rect(this.x, this.y + 10, 5, 10);
        rect(this.x + this.largura - 5, this.y + 10, 5, 10);
        rect(this.x, this.y + this.altura - 20, 5, 10);
        rect(this.x + this.largura - 5, this.y + this.altura - 20, 5, 10);
        break;
    }
  }
}

// --- CLASSE ITEM (Herda de Elemento) ---
class Item extends Elemento {
  constructor(x, y, largura, altura, tipo, cenario, valor) {
    super(x, y, largura, altura, tipo, cenario);
    this.valor = valor; // Valor do item (ex: combustível = 20, kit_reparo = 30)
  }

  mostrar() {
    switch (this.tipo) {
      case 'combustivel':
        fill(255, 255, 0); // Galão amarelo
        rect(this.x, this.y, this.largura, this.altura);
        fill(0);
        rect(this.x + this.largura / 4, this.y - 5, this.largura / 2, 5); // Alça
        break;
      case 'kit_reparo':
        fill(0, 200, 255); // Kit azul claro
        rect(this.x, this.y, this.largura, this.altura);
        fill(255); // Cruz branca
        rect(this.x + this.largura / 3, this.y + 5, this.largura / 3, this.altura - 10);
        rect(this.x + 5, this.y + this.altura / 3, this.largura - 10, this.altura / 3);
        break;
      case 'moeda':
        fill(255, 215, 0); // Moeda dourada
        ellipse(this.x + this.largura / 2, this.y + this.altura / 2, this.largura, this.altura);
        fill(100, 80, 0);
        text('$', this.x + this.largura / 2, this.y + this.altura / 2 + 5);
        textAlign(CENTER, CENTER);
        break;
    }
  }
}

// ==========================================================
// FUNÇÕES DE GERENCIAMENTO DO CENÁRIO
// ==========================================================

function desenharFundo() {
  background(cores.ceu); // Céu

  if (modoCenario === 'campo') {
    // Campo verde dos lados
    fill(cores.campoVerde);
    rect(0, 0, width / 4, height);
    rect(width * 3 / 4, 0, width / 4, height);

    // Estrada de terra
    fill(cores.estradaCampo);
    rect(width / 4, 0, width / 2, height);
  } else { // Cidade
    // Calçadas
    fill(cores.calcadaCidade);
    rect(0, 0, width / 4, height);
    rect(width * 3 / 4, 0, width / 4, height);

    // Asfalto (estrada)
    fill(cores.estradaCidade);
    rect(width / 4, 0, width / 2, height);

    // Linhas da estrada
    fill(255, 255, 0); // Linha amarela
    for (let i = 0; i < height / 50; i++) {
      rect(width / 2 - 2, i * 50 + (frameCount % 50), 4, 20); // Linhas pontilhadas
    }
  }
}

function gerarElementosIniciais(cenario) {
  elementosCenario = []; // Limpa elementos antigos

  // Gera alguns obstáculos e itens aleatórios para começar
  for (let i = 0; i < 8; i++) {
    gerarNovoElemento(cenario, random(-height * 2, 0)); // Espalha acima da tela
  }
}

function gerarNovoElemento(cenario, yPos) {
  let x, largura, altura;
  let tipoElemento;
  let elementoNovo;

  // Define a área jogável (estrada)
  let estradaMinX = width / 4 + 10;
  let estradaMaxX = width * 3 / 4 - 10;
  let larguraEstrada = estradaMaxX - estradaMinX;

  // Decide se será obstáculo ou item
  if (random() < 0.8) { // 80% de chance de ser obstáculo
    if (cenario === 'campo') {
      let r = random();
      if (r < 0.5) { // Árvore
        tipoElemento = 'arvore';
        largura = random(30, 60);
        altura = random(60, 100);
        // Gera fora da estrada, nas laterais
        x = random() < 0.5 ? random(0, width / 4 - largura) : random(width * 3 / 4, width - largura);
      } else if (r < 0.8) { // Pedra
        tipoElemento = 'pedra';
        largura = random(20, 40);
        altura = random(20, 40);
        // Pode gerar um pouco na estrada
        x = random(estradaMinX, estradaMaxX - largura);
      } else { // Trator
        tipoElemento = 'trator';
        largura = random(50, 80);
        altura = random(70, 100);
        x = random(estradaMinX, estradaMaxX - largura);
      }
      elementoNovo = new Obstaculo(x, yPos, largura, altura, tipoElemento, cenario, 15); // Dano: 15
    } else { // Cidade
      let r = random();
      if (r < 0.5) { // Prédio
        tipoElemento = 'predio';
        largura = random(60, 120);
        altura = random(100, 250);
        // Gera fora da estrada, nas calçadas
        x = random() < 0.5 ? random(0, width / 4 - largura) : random(width * 3 / 4, width - largura);
      } else if (r < 0.8) { // Poste
        tipoElemento = 'poste';
        largura = 10;
        altura = random(80, 150);
        // Nas calçadas ou bem na borda da estrada
        x = random() < 0.5 ? random(width / 4 - 20, width / 4 - 5) : random(width * 3 / 4 + 5, width * 3 / 4 + 20);
      } else { // Carro NPC (simula tráfego)
        tipoElemento = 'carro_npc';
        largura = 40;
        altura = 70;
        x = random(estradaMinX, estradaMaxX - largura);
      }
      elementoNovo = new Obstaculo(x, yPos, largura, altura, tipoElemento, cenario, 20); // Dano: 20
    }
  } else { // 20% de chance de ser item
    tipoElemento = random(['combustivel', 'kit_reparo', 'moeda']);
    largura = 30;
    altura = 30;
    x = random(estradaMinX, estradaMaxX - largura); // Itens sempre na estrada

    let valor;
    if (tipoElemento === 'combustivel') valor = 30;
    else if (tipoElemento === 'kit_reparo') valor = 25;
    else valor = 10; // Moeda

    elementoNovo = new Item(x, yPos, largura, altura, tipoElemento, cenario, valor);
  }
  elementosCenario.push(elementoNovo);
}


function gerenciarElementosCenario() {
  for (let i = elementosCenario.length - 1; i >= 0; i--) {
    let el = elementosCenario[i];
    el.mover(); // Move o elemento para baixo
    el.mostrar(); // Desenha o elemento

    // Verifica colisão com o carro
    if (colisao(carro, el)) {
      if (el instanceof Obstaculo) {
        vidaCarro -= el.dano;
        // Limita a vida a 0 para não ficar negativo
        vidaCarro = max(0, vidaCarro);
        elementosCenario.splice(i, 1); // Remove o obstáculo colidido
        // Poderia adicionar um som ou efeito visual aqui para colisão
      } else if (el instanceof Item) {
        if (el.tipo === 'combustivel') {
          combustivelCarro += el.valor;
          combustivelCarro = min(100, combustivelCarro); // Limita a 100
        } else if (el.tipo === 'kit_reparo') {
          vidaCarro += el.valor;
          vidaCarro = min(100, vidaCarro); // Limita a 100
        } else if (el.tipo === 'moeda') {
          pontuacao += el.valor; // Moedas dão pontos
        }
        elementosCenario.splice(i, 1); // Remove o item coletado
        // Poderia adicionar um som ou efeito visual aqui para coleta
      }
    }

    // Remove elementos que saíram da tela e adiciona novos
    if (el.y > height) {
      elementosCenario.splice(i, 1);
      // Adiciona um novo elemento no topo
      gerarNovoElemento(modoCenario, random(-200, -50)); // Gera um pouco acima da tela
    }
  }
}

function alternarCenario() {
  if (modoCenario === 'campo') {
    modoCenario = 'cidade';
    console.log("Transição para Cidade!");
  } else {
    modoCenario = 'campo';
    console.log("Transição para Campo Agro!");
  }
  // Regenera elementos para o novo cenário
  gerarElementosIniciais(modoCenario);
  // Aumenta ligeiramente a velocidade base do cenário em cada transição para maior dificuldade
  // velocidadeCenarioBase += 0.5;
  // velocidadeCenarioAtual = velocidadeCenarioBase; // Reseta a velocidade para a base aumentada
}


// ==========================================================
// FUNÇÕES DE JOGO E INTERFACE
// ==========================================================

function colisao(obj1, obj2) {
  // Simplificado para colisão retangular
  return obj1.x < obj2.x + obj2.largura &&
         obj1.x + obj1.largura > obj2.x &&
         obj1.y < obj2.y + obj2.altura &&
         obj1.y + obj1.altura > obj2.y;
}

function atualizarIU() {
  // Fundo para as informações da UI
  fill(0, 0, 0, 150); // Fundo semi-transparente
  rect(0, 0, width, 120);

  // Exibe a pontuação
  fill(255);
  textSize(24);
  text(`PONTOS: ${floor(pontuacao)}`, 10, 30);

  // Exibe a vida do carro
  textSize(18);
  text(`VIDA:`, 10, 60);
  noFill();
  stroke(255);
  rect(70, 48, 100, 15);
  fill(0, 255, 0); // Barra de vida verde
  rect(70, 48, map(vidaCarro, 0, 100, 0, 100), 15);

  // Exibe o combustível do carro
  text(`COMB:`, 10, 85);
  noFill();
  stroke(255);
  rect(70, 73, 100, 15);
  fill(0, 0, 255); // Barra de combustível azul
  rect(70, 73, map(combustivelCarro, 0, 100, 0, 100), 15);

  // Exibe a velocidade atual
  fill(255);
  text(`VEL: ${floor(velocidadeCenarioAtual)} km/h`, 10, 110);


  // Exibe o modo de cenário atual no canto superior direito
  fill(255);
  textAlign(RIGHT);
  textSize(20);
  text(`CENÁRIO: ${modoCenario.toUpperCase()}`, width - 10, 30);
  textAlign(LEFT); // Reseta para o alinhamento padrão
}

function verificarGameOver() {
  if (vidaCarro <= 0 || combustivelCarro <= 0) {
    textSize(50);
    fill(255, 0, 0);
    textAlign(CENTER, CENTER);
    text("GAME OVER", width / 2, height / 2);
    textSize(25);
    fill(255);
    text(`Pontuação Final: ${floor(pontuacao)}`, width / 2, height / 2 + 50);
    text("Pressione 'R' para Reiniciar", width / 2, height / 2 + 90);
    noLoop(); // Para o jogo
  }
}

function keyPressed() {
  if (keyCode === 82 && (vidaCarro <= 0 || combustivelCarro <= 0)) { // 'R' para Reiniciar
    reiniciarJogo();
  }
}

function reiniciarJogo() {
  vidaCarro = 100;
  combustivelCarro = 100;
  pontuacao = 0;
  velocidadeCenarioAtual = velocidadeCenarioBase;
  distanciaPercorridaNoCenario = 0;
  modoCenario = 'campo';
  carro = new Carro(); // Recria o carro
  gerarElementosIniciais(modoCenario); // Regenera elementos
  loop(); // Inicia o loop draw novamente
}
